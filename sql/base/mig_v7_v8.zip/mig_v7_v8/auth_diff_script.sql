SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE `account` MODIFY COLUMN `muteby`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL AFTER `mutereason`;
UPDATE `account` SET `muteby` = NULL WHERE `muteby` = '' ;

ALTER TABLE `account_access` DROP COLUMN `Comment`;

ALTER TABLE `account_banned` MODIFY COLUMN `id`  int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Account id' FIRST ;
ALTER TABLE `account_banned` MODIFY COLUMN `bandate`  int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `realm`;
ALTER TABLE `account_banned` MODIFY COLUMN `unbandate`  int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `bandate`;
ALTER TABLE `account_banned` MODIFY COLUMN `bannedby`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL AFTER `unbandate`;
ALTER TABLE `account_banned` MODIFY COLUMN `active`  tinyint(3) UNSIGNED NOT NULL DEFAULT 1 AFTER `banreason`;

RENAME TABLE `account_strafe` TO `account_punishment` ;
ALTER TABLE `account_punishment` CHANGE COLUMN `strafpunkte` `penalty_points`  int(11) UNSIGNED NOT NULL AFTER `by`;

RENAME TABLE `account_verwarnung` TO `account_warning` ;

DROP TABLE IF EXISTS `rbac_account_groups`;
CREATE TABLE `rbac_account_groups` (
  `accountId` int(10) unsigned NOT NULL COMMENT 'Account id',
  `groupId` int(10) unsigned NOT NULL COMMENT 'Group id',
  `realmId` int(11) NOT NULL DEFAULT '-1' COMMENT 'Realm Id, -1 means all',
  PRIMARY KEY (`accountId`,`groupId`,`realmId`),
  KEY `fk__rbac_account_groups__rbac_groups` (`groupId`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Account-Group relation';


ALTER TABLE `realmcharacters` MODIFY COLUMN `realmid`  int(10) UNSIGNED NOT NULL DEFAULT 0 FIRST ;
ALTER TABLE `realmcharacters` MODIFY COLUMN `acctid`  int(10) UNSIGNED NOT NULL AFTER `realmid`;

ALTER TABLE `realmlist` MODIFY COLUMN `localAddress`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '127.0.0.1' AFTER `address`;
ALTER TABLE `realmlist` MODIFY COLUMN `localSubnetMask`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '255.255.255.0' AFTER `localAddress`;
ALTER TABLE `realmlist` MODIFY COLUMN `flag`  tinyint(3) UNSIGNED NOT NULL DEFAULT 2 AFTER `icon`;
ALTER TABLE `realmlist` DROP COLUMN `color`;
ALTER TABLE `realmlist` DROP COLUMN `online`;

ALTER TABLE `uptime` DROP COLUMN `startstring`;

SET FOREIGN_KEY_CHECKS=1;