SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE `character_currency` DROP COLUMN `season_count`;

DROP TABLE IF EXISTS `character_guild_reputation`;
CREATE TABLE `character_guild_reputation` (
  `guid` int(10) unsigned NOT NULL,
  `guildid` int(10) unsigned NOT NULL COMMENT 'Guild Identificator',
  `disband_time` int(10) unsigned NOT NULL DEFAULT '0',
  `weekly_rep` bigint(20) NOT NULL DEFAULT '0',
  `total_rep` bigint(20) NOT NULL DEFAULT '0',
  UNIQUE KEY `guid_key` (`guid`),
  KEY `guildid_key` (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Characters Guild Reputation System';

DROP TABLE IF EXISTS `cronjobs`;
CREATE TABLE `cronjobs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `guid` int(11) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `param1` varchar(255) NOT NULL,
  `param2` varchar(255) NOT NULL,
  `x` float NOT NULL DEFAULT '0',
  `y` float NOT NULL DEFAULT '0',
  `z` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



ALTER TABLE `guild_achievement_progress` MODIFY COLUMN `counter`  int(10) UNSIGNED NOT NULL AFTER `criteria`;

DROP TABLE IF EXISTS `guild_challenges_completed`;
CREATE TABLE `guild_challenges_completed` (
  `guildId` int(10) unsigned NOT NULL DEFAULT '0',
  `challengeId` int(10) unsigned DEFAULT NULL,
  `dateCompleted` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`guildId`),
  KEY `challengeId` (`challengeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `mail` MODIFY COLUMN `money`  bigint(20) UNSIGNED NOT NULL DEFAULT 0 AFTER `deliver_time`;
ALTER TABLE `mail` MODIFY COLUMN `cod`  bigint(20) UNSIGNED NOT NULL DEFAULT 0 AFTER `money`;


SET FOREIGN_KEY_CHECKS=1;